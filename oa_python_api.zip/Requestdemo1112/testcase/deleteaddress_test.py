import unittest
from api2018.Sendhttp import SendHttp
from api2018 import Common
class deleteadress(unittest.TestCase):
    def setUp(self):
        self.deurl="/fgadmin/address/delete"
    def test_delete(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={
            "id":77243286
        }
        result=SendHttp.send_post_bycookies(self,self.deurl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_delete1(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={
            "id":"77243286"
        }
        result=SendHttp.send_post_bycookies(self,self.deurl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)
    def test_delete2(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={
            "id":111
        }
        result=SendHttp.send_post_bycookies(self,self.deurl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 400)
