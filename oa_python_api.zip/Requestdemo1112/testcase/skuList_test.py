import unittest
from api2018.Sendhttp import SendHttp
from api2018 import Common
class skuList(unittest.TestCase):
    def setUp(self):
        self.loginurl="/common/fgadmin/login"
        self.skulisturl="/common/skuList"
    def test_AllskuList(self):
        skulist_result=SendHttp.sent_get(self,self.skulisturl)
        print(skulist_result)
        self.assertEqual(skulist_result['code'],200)
    def test_skuList1(self):
        data={"goodsId":1 }
        skulist_result=SendHttp.sent_get(self,self.skulisturl,data)
        print(skulist_result)
        self.assertEqual(skulist_result['code'],200)
    def test_skuList2(self):
        data={"goodsId":"1" }
        skulist_result=SendHttp.sent_get(self,self.skulisturl,data)
        print(skulist_result)
        self.assertEqual(skulist_result['code'],200)

    def test_skuList3(self):
        data={"goodsId":2147486658911111}
        skulist_result=SendHttp.sent_get(self,self.skulisturl,data)
        print(skulist_result)
        self.assertEqual(skulist_result['code'],200)

    def test_skuList4(self):
        data={"goodsId":"abc1" }
        skulist_result=SendHttp.sent_get(self,self.skulisturl,data)
        print(skulist_result)
        self.assertEqual(skulist_result['code'],200)