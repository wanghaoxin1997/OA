package com.webtest.demo;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.webtest.dataprovider.NSDataProvider;

public class Para_Test {

	@Test(dataProvider="txt",dataProviderClass=NSDataProvider.class)
	public void loginFail(String usename,String password) {
	
		System.out.println(usename);
		
		
	}
	
}
