import requests
import json
url1="http://study-perf.qa.netease.com/common/skuList?goodsId=1"
url2="http://study-perf.qa.netease.com/common/skuList"
paraGoods={"goodsId":"1"}
res1=requests.get(url1)
print(res1.json())#将json变成字典形式
res=requests.get(url2,params=paraGoods)
print(json.loads(res.text))#将json变成文本格式

def sent_get(url,paraData):
    res=requests.get(url,params=paraData)
    return json.dumps(res.json(),indent=2,sort_keys=True)#将json变成数据化格式

print(sent_get(url2,paraGoods))