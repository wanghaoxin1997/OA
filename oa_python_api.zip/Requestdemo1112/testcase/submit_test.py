import unittest
from api2018.Sendhttp import SendHttp
from api2018 import Common
class transportfree(unittest.TestCase):
    def setUp(self):
        self.loginurl="/common/fgadmin/login"
        self.submiturl="/fgadmin/orders/submit"
    def test_submitFail2(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":"2","skuNumber":"1",
                    "stockIds":"74966312",
                    "receiverName":"测试用户20","cellPhone":"12345678901",
                    "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
                    "area":"裕华区","voiceStatus":1,"needInvoice":1,"invoiceHead":"",
                    "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
                    "accessDevice":0
        }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_submitSuccess1(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":"2","skuNumber":"1",
              "stockIds":"74966312",
              "receiverName":"测试用户20","cellPhone":"12345678901",
              "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
              "area":"裕华区","voiceStatus":0,"needInvoice":0,"invoiceHead":"",
              "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
              "accessDevice":0
              }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'],400)

    def test_submitFail3(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":2,"skuNumber":"1",
          "stockIds":"74966312",
          "receiverName":"测试用户20","cellPhone":"12345678901",
          "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
          "area":"裕华区","voiceStatus":0,"needInvoice":0,"invoiceHead":"",
          "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
          "accessDevice":0
          }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_submitFail4(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":"","skuNumber":"1",
              "stockIds":"74966312",
              "receiverName":"测试用户20","cellPhone":"12345678901",
              "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
              "area":"裕华区","voiceStatus":0,"needInvoice":0,"invoiceHead":"",
              "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
              "accessDevice":0
              }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_submitFail5(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":2,"skuNumber":"100000000",
              "stockIds":"74966312",
              "receiverName":"测试用户20","cellPhone":"12345678901",
              "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
              "area":"裕华区","voiceStatus":0,"needInvoice":0,"invoiceHead":"",
              "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
              "accessDevice":0
              }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_submitFail6(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":2,"skuNumber":"1",
              "stockIds":"74966312",
              "receiverName":"测试用户20","cellPhone":"12345678901",
              "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
              "area":"裕华区","voiceStatus":0,"needInvoice":0,"invoiceHead":"",
              "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
              "accessDevice":0
              }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_submitFail7(self):
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        data={"skuIds":"2","skuNumber":"1,3",
              "stockIds":"74966312",
              "receiverName":"测试用户20","cellPhone":"12345678901",
              "addressDetail":"河北师大","province":"河北省","city":"石家庄市",
              "area":"裕华区","voiceStatus":0,"needInvoice":0,"invoiceHead":"",
              "transportFee":0,"logisticsCompanyId":1,"accessSource":"noSource",
              "accessDevice":0
              }
        result=SendHttp.send_post_bycookies(self,self.submiturl,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)
