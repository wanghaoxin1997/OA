import requests
import json
url="http://study-perf.qa.netease.com/common/fgadmin/login"
user={
    "phoneArea":"86",
    "phoneNumber":"20000000000",
    "password":"netease123"
}
header={"Content-Type":"application/json"}
res=requests.post(url,data=json.dumps(user),headers=header)
print(res.json())

def send_post(url,data):
    header={"Content-Type":"application/json"}
    r=requests.post(url,data=json.dumps(data),headers=header).json()
    return  json.dumps(r,indent=2,sort_keys=True)

print(send_post(url,user))