import unittest
from api2018.Sendhttp import SendHttp
from api2018 import Common
class newAdress(unittest.TestCase):

    def setUp(self):
        self.url="/fgadmin/address/new"

    def test_adress(self):
        data={"receiverName":"张三","cellPhone":"12615813537","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 400)
    def test_adress1(self):
        data={"id":"123","receiverName":"张三","cellPhone":"12615813537","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_adress2(self):
        data={"receiverName":123,"cellPhone":"12615813537","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_adress3(self):
        data={"receiverName":"","cellPhone":"12615813537","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_adress4(self):
        data={"receiverName":"张三","cellPhone":"12615813537","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_adress5(self):
        data={"receiverName":"张三","cellPhone":123,"addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 200)

    def test_adress6(self):
        data={"receiverName":"张三","cellPhone":"","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 400)

    def test_adress7(self):
        data={"receiverName":"张三","cellPhone":"12345678912","addressDetail":"1栋3单元","province":"浙江省",
              "city":"杭州市","area":"滨江区"}
        user = {"phoneArea": "86", "phoneNumber": "20000000000", "password": "netease123"}
        cookies=Common.getcookie(user)
        result=SendHttp.send_post_bycookies(self,self.url,data,cookies)
        print(result)
        self.assertEqual(result['code'], 400)